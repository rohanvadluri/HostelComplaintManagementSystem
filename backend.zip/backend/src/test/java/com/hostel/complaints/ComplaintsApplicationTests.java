package com.hostel.complaints;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ComplaintsApplicationTests {

	@Test
	void contextLoads() {
	}

}
