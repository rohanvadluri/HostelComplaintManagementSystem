INSERT INTO users (name, email, password, role)
VALUES ('Admin', 'admin2025@gmail.com', 'admin2025', 'ADMIN');
