package com.hostel.complaints;

public class EmailAlreadyExistsException {
}
